(function() {
  "use strict";
  const BUTTON_ID = "tryiton-floating-btn";
  const IGNORE_PATTERNS = [
    /logo/i,
    /icon/i,
    /avatar/i,
    /profile/i,
    /sprite/i,
    /banner/i,
    /badge/i,
    /flag/i,
    /placeholder/i
  ];
  const IGNORE_CONTAINERS = ["nav", "header", "footer", "aside"];
  function isIgnored(img) {
    const src = img.src || img.dataset.src || "";
    if (IGNORE_PATTERNS.some((p) => p.test(src))) return true;
    let el = img;
    while (el) {
      if (IGNORE_CONTAINERS.includes(el.tagName.toLowerCase())) return true;
      el = el.parentElement;
    }
    return false;
  }
  function scoreImage(img) {
    const rect = img.getBoundingClientRect();
    const w = rect.width, h = rect.height;
    if (w < 200 || h < 200) return null;
    if (isIgnored(img)) return null;
    const src = img.src || img.currentSrc || img.dataset.src || "";
    if (!src || src.startsWith("data:")) return null;
    const area = w * h;
    const cx = rect.left + w / 2;
    const cy = rect.top + h / 2;
    const vw = window.innerWidth, vh = window.innerHeight;
    const centerDist = Math.sqrt(Math.pow(cx - vw / 2, 2) + Math.pow(cy - vh / 2, 2));
    const maxDist = Math.sqrt((vw / 2) ** 2 + (vh / 2) ** 2);
    const centralityScore = 1 - centerDist / maxDist;
    const score = area * 0.6 + centralityScore * 1e5 * 0.4;
    return { src, score, rect };
  }
  function detectProductImage() {
    const imgs = Array.from(document.querySelectorAll("img"));
    const scored = imgs.map(scoreImage).filter((x) => x !== null).sort((a, b) => b.score - a.score);
    const divs = Array.from(document.querySelectorAll("div, section, figure, a"));
    for (const div of divs) {
      const bg = window.getComputedStyle(div).backgroundImage;
      if (bg && bg !== "none" && bg.startsWith("url")) {
        const match = bg.match(/url\(["']?([^"')]+)["']?\)/);
        if (match && match[1]) {
          const rect = div.getBoundingClientRect();
          if (rect.width > 200 && rect.height > 200) {
            scored.push({ src: match[1], score: rect.width * rect.height * 0.5, rect });
          }
        }
      }
    }
    return scored.length ? scored[0].src : null;
  }
  const CATEGORY_RULES = [
    // Wearables
    ["glasses", /glasses|sunglasses|eyewear|eyeglasses|optical|frame|lens|goggles/i],
    ["shoes", /shoes?|sneakers?|boots?|heels?|sandals?|loafers?|slip.on|footwear|trainers?/i],
    ["watch", /watch|timepiece|wristwatch/i],
    ["jewelry", /necklace|ring|earring|bracelet|pendant|anklet|jewelry|jewellery|bangle/i],
    ["bag", /handbag|purse|tote|backpack|clutch|satchel|crossbody|shoulder bag/i],
    ["hat", /hat|cap|beanie|beret|fedora|snapback|bucket hat/i],
    ["nails", /nail polish|nail art|nail gel|manicure/i],
    ["makeup", /lipstick|foundation|mascara|eyeshadow|blush|concealer|makeup|cosmetics/i],
    ["hair", /wig|hair extensions?|hair color|hairpiece/i],
    ["pants", /pants|jeans|trousers|shorts|leggings|sweatpants|joggers|chinos/i],
    ["dress", /dress|gown|jumpsuit|romper|skirt|maxi|midi/i],
    ["jacket", /jacket|coat|hoodie|blazer|puffer|parka|cardigan|sweater/i],
    // Space Intelligence
    ["furniture", /sofa|couch|armchair|chair|table|desk|bed|wardrobe|bookcase|bookshelf|shelf|cabinet|dresser|sideboard|bench|ottoman|futon|recliner|furniture/i],
    ["electronics", /tv|television|monitor|laptop|computer|speaker|soundbar|projector|console|printer|tablet|smart home|router|electronics/i],
    ["lighting", /lamp|chandelier|pendant light|ceiling light|floor lamp|wall light|sconce|spotlight|led strip|lighting|light fixture/i],
    ["plants", /plant|succulent|cactus|fern|potted|bonsai|orchid|monstera|herb|flower pot|indoor plant/i],
    ["garden", /garden|outdoor|patio|terrace|balcony|lawn|plant pot|planter|pergola|gazebo|barbecue|bbq|garden furniture/i],
    ["kitchen", /coffee maker|kettle|toaster|blender|microwave|air fryer|stand mixer|dishwasher|fridge|refrigerator|kitchen appliance|cookware|pot|pan/i]
  ];
  function detectCategory() {
    var _a, _b, _c, _d, _e;
    const jsonLdTexts = [];
    document.querySelectorAll('script[type="application/ld+json"]').forEach((s) => {
      try {
        jsonLdTexts.push(JSON.stringify(JSON.parse(s.textContent || "")));
      } catch {
      }
    });
    const signals = [
      document.title,
      ((_a = document.querySelector("h1")) == null ? void 0 : _a.textContent) ?? "",
      ((_b = document.querySelector('[class*="breadcrumb"]')) == null ? void 0 : _b.textContent) ?? "",
      ((_c = document.querySelector('[class*="category"]')) == null ? void 0 : _c.textContent) ?? "",
      ((_d = document.querySelector("[data-category]")) == null ? void 0 : _d.getAttribute("data-category")) ?? "",
      ((_e = document.querySelector('meta[name="keywords"]')) == null ? void 0 : _e.getAttribute("content")) ?? "",
      window.location.pathname,
      window.location.href,
      ...jsonLdTexts
    ].join(" ");
    for (const [cat, pattern] of CATEGORY_RULES) {
      if (pattern.test(signals)) return cat;
    }
    return "tops";
  }
  let _detectedCategory = null;
  function getCachedCategory() {
    if (!_detectedCategory) _detectedCategory = detectCategory();
    return _detectedCategory;
  }
  function detectProductSpecs() {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j, _k, _l;
    const specs = {};
    specs.title = (_c = ((_a = document.querySelector("h1")) == null ? void 0 : _a.textContent) || ((_b = document.querySelector('[itemprop="name"]')) == null ? void 0 : _b.textContent) || document.title) == null ? void 0 : _c.trim().slice(0, 120);
    specs.brand = (_g = ((_d = document.querySelector('[itemprop="brand"]')) == null ? void 0 : _d.textContent) || ((_e = document.querySelector('[class*="brand"]')) == null ? void 0 : _e.textContent) || ((_f = document.querySelector('[class*="vendor"]')) == null ? void 0 : _f.textContent)) == null ? void 0 : _g.trim().slice(0, 60);
    specs.price = (_k = ((_h = document.querySelector('[itemprop="price"]')) == null ? void 0 : _h.getAttribute("content")) || ((_i = document.querySelector('[class*="price"]')) == null ? void 0 : _i.textContent) || ((_j = document.querySelector('[class*="Price"]')) == null ? void 0 : _j.textContent)) == null ? void 0 : _k.trim().slice(0, 30);
    const bodyText = document.body.innerText.slice(0, 8e3);
    const dimMatch = bodyText.match(
      /(?:dimensions?|size|measurements?|width|height|depth|length)[:\s]+([\d.]+\s*[x×\-]\s*[\d.]+(?:\s*[x×\-]\s*[\d.]+)?\s*(?:cm|mm|inches?|in|"|\')?)/i
    );
    if (dimMatch) specs.dimensions = dimMatch[0].trim().slice(0, 100);
    const matMatch = bodyText.match(
      /(?:material|fabric|composition|made from|made of)[:\s]+([a-zA-Z0-9%,\s]+)/i
    );
    if (matMatch) specs.materials = matMatch[0].trim().slice(0, 100);
    const sizeTableEl = document.querySelector('[class*="size-chart"], [class*="sizeChart"], [id*="size-guide"], table');
    if (sizeTableEl) {
      specs.sizeChart = (_l = sizeTableEl.textContent) == null ? void 0 : _l.trim().slice(0, 300);
    }
    return specs;
  }
  const CAT_INFO = {
    tops: { icon: "👕", label: "Top" },
    pants: { icon: "👖", label: "Pants" },
    jacket: { icon: "🧥", label: "Jacket" },
    dress: { icon: "👗", label: "Dress" },
    shoes: { icon: "👟", label: "Shoes" },
    glasses: { icon: "🕶", label: "Glasses" },
    watch: { icon: "⌚", label: "Watch" },
    jewelry: { icon: "💍", label: "Jewelry" },
    hat: { icon: "🧢", label: "Hat" },
    bag: { icon: "👜", label: "Bag" },
    hair: { icon: "💇", label: "Hair" },
    makeup: { icon: "💄", label: "Makeup" },
    nails: { icon: "💅", label: "Nails" },
    furniture: { icon: "🛋️", label: "Furniture" },
    electronics: { icon: "📺", label: "Electronics" },
    lighting: { icon: "💡", label: "Lighting" },
    plants: { icon: "🌱", label: "Plants" },
    garden: { icon: "🌿", label: "Garden" },
    kitchen: { icon: "🍳", label: "Kitchen" },
    other: { icon: "📦", label: "Other" }
  };
  function createButton() {
    if (document.getElementById(BUTTON_ID)) return;
    const cat = getCachedCategory();
    const info = CAT_INFO[cat];
    const isSpace = ["furniture", "electronics", "lighting", "plants", "garden", "kitchen"].includes(cat);
    const btn = document.createElement("div");
    btn.id = BUTTON_ID;
    btn.innerHTML = `
    <div class="tryiton-icon">${info.icon}</div>
    <span class="tryiton-label">${isSpace ? `Place in Space` : `Try on ${info.label}`}</span>
  `;
    Object.assign(btn.style, {
      position: "fixed",
      bottom: "24px",
      right: "24px",
      zIndex: "2147483647",
      background: isSpace ? "linear-gradient(135deg, #10b981, #059669)" : "linear-gradient(135deg, #6366f1, #8b5cf6)",
      color: "white",
      borderRadius: "50px",
      padding: "12px 20px",
      cursor: "pointer",
      display: "flex",
      alignItems: "center",
      gap: "8px",
      boxShadow: isSpace ? "0 4px 24px rgba(16,185,129,0.5)" : "0 4px 24px rgba(99,102,241,0.5)",
      fontSize: "14px",
      fontFamily: "'Inter', system-ui, sans-serif",
      fontWeight: "600",
      userSelect: "none",
      transition: "transform 0.2s, box-shadow 0.2s",
      backdropFilter: "blur(10px)",
      border: "1px solid rgba(255,255,255,0.2)"
    });
    btn.addEventListener("mouseenter", () => {
      btn.style.transform = "scale(1.05)";
      btn.style.boxShadow = "0 8px 32px rgba(99,102,241,0.7)";
    });
    btn.addEventListener("mouseleave", () => {
      btn.style.transform = "scale(1)";
      btn.style.boxShadow = "0 4px 24px rgba(99,102,241,0.5)";
    });
    btn.addEventListener("click", () => {
      const src = detectProductImage();
      const category = getCachedCategory();
      const specs = detectProductSpecs();
      if (src) {
        try {
          chrome.runtime.sendMessage({ type: "PRODUCT_DETECTED", src, category, specs });
        } catch {
        }
      } else {
        startManualSelection();
      }
    });
    document.body.appendChild(btn);
  }
  let selecting = false;
  let overlayTarget = null;
  function startManualSelection() {
    if (selecting) return;
    selecting = true;
    const toast = document.createElement("div");
    toast.id = "tryiton-toast";
    toast.textContent = "Click a product image to select it";
    Object.assign(toast.style, {
      position: "fixed",
      top: "16px",
      left: "50%",
      transform: "translateX(-50%)",
      background: "rgba(30,30,30,0.95)",
      color: "white",
      padding: "12px 20px",
      borderRadius: "8px",
      zIndex: "2147483646",
      fontSize: "14px",
      fontFamily: "Inter, system-ui, sans-serif",
      pointerEvents: "none"
    });
    document.body.appendChild(toast);
    const onMove = (e) => {
      const target = document.elementFromPoint(e.clientX, e.clientY);
      if (target && target !== overlayTarget) {
        if (overlayTarget) overlayTarget.style.outline = "";
        overlayTarget = target;
        overlayTarget.style.outline = "3px solid #6366f1";
      }
    };
    const onClick = (e) => {
      e.preventDefault();
      e.stopPropagation();
      cleanup();
      const el = document.elementFromPoint(e.clientX, e.clientY);
      if (!el) return;
      let src = null;
      if (el instanceof HTMLImageElement) {
        src = el.src || el.currentSrc;
      } else {
        const bg = window.getComputedStyle(el).backgroundImage;
        const m = bg.match(/url\(["']?([^"')]+)["']?\)/);
        if (m) src = m[1];
      }
      if (src) {
        try {
          const specs = detectProductSpecs();
          chrome.runtime.sendMessage({ type: "PRODUCT_DETECTED", src, category: getCachedCategory(), specs });
        } catch {
        }
      }
    };
    const cleanup = () => {
      selecting = false;
      if (overlayTarget) overlayTarget.style.outline = "";
      overlayTarget = null;
      toast.remove();
      document.removeEventListener("mousemove", onMove, true);
      document.removeEventListener("click", onClick, true);
    };
    document.addEventListener("mousemove", onMove, true);
    document.addEventListener("click", onClick, true);
    setTimeout(cleanup, 15e3);
  }
  setTimeout(createButton, 1200);
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg.type === "START_MANUAL_SELECT") startManualSelection();
  });
})();
