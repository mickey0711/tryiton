(function() {
  "use strict";
  chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(["replicateToken"], (result) => {
      if (!result.replicateToken) {
        console.warn("[TryItOn] Replicate token not set. Configure via extension options.");
      }
    });
  });
  let lastProductSrc = null;
  let lastProductCategory = "tops";
  let lastProductSpecs = null;
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    var _a;
    if (msg.type === "PRODUCT_DETECTED") {
      lastProductSrc = msg.src;
      lastProductCategory = msg.category ?? "tops";
      lastProductSpecs = msg.specs ?? null;
      if ((_a = chrome.action) == null ? void 0 : _a.openPopup) {
        chrome.action.openPopup().catch(() => {
        });
      }
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "GET_LAST_PRODUCT") {
      sendResponse({ src: lastProductSrc, category: lastProductCategory, specs: lastProductSpecs });
      return true;
    }
    if (msg.type === "CLEAR_PRODUCT") {
      lastProductSrc = null;
      lastProductCategory = "tops";
      lastProductSpecs = null;
      sendResponse({ ok: true });
      return true;
    }
    if (msg.type === "FETCH_IMAGE_BLOB") {
      fetchImageAsBase64(msg.url).then((data) => sendResponse({ ok: true, data })).catch((err) => sendResponse({ ok: false, error: String(err) }));
      return true;
    }
    if (msg.type === "START_MANUAL_SELECT") {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        var _a2;
        if ((_a2 = tabs[0]) == null ? void 0 : _a2.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: "START_MANUAL_SELECT" });
        }
      });
      return true;
    }
    if (msg.type === "GET_TOKENS") {
      chrome.storage.local.get(["accessToken", "refreshToken"], (data) => {
        sendResponse(data);
      });
      return true;
    }
    if (msg.type === "SET_TOKENS") {
      chrome.storage.local.set({
        accessToken: msg.accessToken,
        refreshToken: msg.refreshToken
      }, () => sendResponse({ ok: true }));
      return true;
    }
    if (msg.type === "CLEAR_TOKENS") {
      chrome.storage.local.remove(
        ["accessToken", "refreshToken"],
        () => sendResponse({ ok: true })
      );
      return true;
    }
    sendResponse({ ok: false, error: "Unknown message type: " + msg.type });
    return false;
  });
  async function fetchImageAsBase64(url) {
    const response = await fetch(url, { mode: "cors" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const blob = await response.blob();
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }
})();
